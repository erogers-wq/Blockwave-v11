-- =====================================================================
--  BLOCKWAVE — complete Supabase setup
--  Paste this whole file into: Supabase -> SQL Editor -> New query -> Run
--
--  Safe to run at any time. It creates anything missing, repairs
--  anything broken, and never deletes a player's score.
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1. The table (created only if it does not already exist)
-- ---------------------------------------------------------------------
create table if not exists public.blockwave_scores (
  device      text primary key,          -- one row per device
  name        text        not null default 'Player',
  score       bigint      not null default 0,
  day         integer     not null default 0,
  prestige    smallint    not null default 0,
  level       integer     not null default 1,
  colour      text        not null default '#FFFFFF',
  grad        text        not null default '',
  gspd        smallint    not null default 4,
  crest       smallint    not null default 0,
  updated_at  timestamptz not null default now()
);

-- ---------------------------------------------------------------------
-- 2. Columns added in later versions of the game
-- ---------------------------------------------------------------------
alter table public.blockwave_scores add column if not exists day        integer     not null default 0;
alter table public.blockwave_scores add column if not exists prestige   smallint    not null default 0;
alter table public.blockwave_scores add column if not exists level      integer     not null default 1;
alter table public.blockwave_scores add column if not exists colour     text        not null default '#FFFFFF';
alter table public.blockwave_scores add column if not exists grad       text        not null default '';
alter table public.blockwave_scores add column if not exists gspd       smallint    not null default 4;
alter table public.blockwave_scores add column if not exists crest      smallint    not null default 0;
alter table public.blockwave_scores add column if not exists updated_at timestamptz not null default now();

-- ---------------------------------------------------------------------
-- 3. Remove old constraints that could reject a valid submission
-- ---------------------------------------------------------------------
alter table public.blockwave_scores drop constraint if exists blockwave_name_len;
alter table public.blockwave_scores drop constraint if exists blockwave_score_ok;
alter table public.blockwave_scores drop constraint if exists blockwave_prestige_ok;
alter table public.blockwave_scores drop constraint if exists blockwave_level_ok;
alter table public.blockwave_scores drop constraint if exists blockwave_grad_len;

-- ---------------------------------------------------------------------
-- 4. Indexes for the two boards (high score, and rank)
-- ---------------------------------------------------------------------
create index if not exists blockwave_score_idx on public.blockwave_scores (score desc);
create index if not exists blockwave_rank_idx  on public.blockwave_scores (prestige desc, level desc);

-- ---------------------------------------------------------------------
-- 5. Security. The public key may only read the board and write one row.
--    It cannot drop the table or touch anything else in your project.
-- ---------------------------------------------------------------------
alter table public.blockwave_scores enable row level security;

drop policy if exists "anyone can read the board"   on public.blockwave_scores;
drop policy if exists "anyone can add their row"    on public.blockwave_scores;
drop policy if exists "anyone can update their row" on public.blockwave_scores;

create policy "anyone can read the board"
  on public.blockwave_scores for select
  to anon, authenticated
  using (true);

create policy "anyone can add their row"
  on public.blockwave_scores for insert
  to anon, authenticated
  with check (true);

create policy "anyone can update their row"
  on public.blockwave_scores for update
  to anon, authenticated
  using (true) with check (true);

-- ---------------------------------------------------------------------
-- 6. Make sure the API role can reach the table at all
-- ---------------------------------------------------------------------
grant usage on schema public to anon, authenticated;
grant select, insert, update on public.blockwave_scores to anon, authenticated;

-- ---------------------------------------------------------------------
-- 7. Bring every existing row up to date so older app builds still see
--    them (the boards are all-time now, so the date no longer matters)
-- ---------------------------------------------------------------------
update public.blockwave_scores
   set day = floor(extract(epoch from now()) / 86400)::int
 where day <> floor(extract(epoch from now()) / 86400)::int;

-- ---------------------------------------------------------------------
-- 8. Check the result. You should see your players listed.
-- ---------------------------------------------------------------------
select name, score, prestige, level, crest, updated_at
  from public.blockwave_scores
 order by score desc
 limit 20;
